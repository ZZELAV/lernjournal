---
marp: true
title: M214 Marp
theme: custom
header: Valentino Panico
footer: M214
---

<!-- _class: lead -->

# Präsentationstool Marp

Valentino Panico

![marp h:400](img/marp.png)

---

# Inhalt

* Was ist Marp
* Einrichtung mit VS Code
* Live Demo

---

# Was ist Marp

* ###### **Mar**kdown **P**resentation
* Yuki Hattori
* vor 5 Jahren
* mdSlide -> Marp
* Markdown, HTML & CSS
* verschiedene Weiterentwicklungen

<!--
Marp -> MARkdown Presentation
Gründer ist Yuki Hattori
gegründet vor 5 Jahren
zuerst hiess es mdSlide, 2019 umbenannt zu Marp
um Präs. zu schreiben wird Markdown, HTML und CSS genutzt
bereits verschiedene Weiterentwicklungen wie:
    - Marp for VS Code
    - Marp CLI
    - Marp Web
-->

---

# Einrichtung mit VS Code

* Grundstruktur erstellen
* Einstellungen
  - .vscode/settings.json
* Theme
  - vordefinierte
  - eigenes
* Präsentation schreiben

<!--
Ordner mit Markdown-File erstellen
Einstellungen in ".vscode/settings.json" vornehmen, z.B.:
    - wo liegt das Theme
    - wie wird exportiert
es gibt 3 vordefinierte Themes (default, uncover, gaia)
um präs. zu schreiben muss ein addon in vs code installieren und definieren das marp genutzt wird (nächste folie)
-->

---

# Einrichtung mit VS Code

```
---
marp: true
title: Titel
theme: gaia
header: Header
footer: Footer
---
```

<!--
als erstes drei striche
dann "marp: true" und dann kann marp genutzt werden
zusätzlich:
    - title
    - theme
    - header
    - footer
    - etc.
und zum schluss wieder drei striche
-->

---

# Einrichtung mit VS Code

```
# Überschrift 1

Das ist **normaler** Text

- Liste 1
- Liste 2

> Blocktext

![marp h:150](img/marp.png)

---
```

<!--
beispiel einer folie
geschrieben in markdown
sieht dann so aus (nächste folie)
-->

---

# Überschrift 1

Das ist **normaler** Text

- Liste 1
- Liste 2

> Blocktext

![marp h:150](img/marp.png)

---

# Live Demo

---

<!-- _class: end -->

# Ende